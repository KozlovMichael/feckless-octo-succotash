package kmy.homework_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    Thread splash_time = new Thread()
    {
        public void run() {
            try
            {
                sleep(2000);
            }
            catch (InterruptedException e) {
                e.printStackTrace(); }
            finally {
                finish();
            }
            Intent next_activity = new Intent(MainActivity.this,Activity_2.class);
            startActivity(next_activity);

        }
    };
    splash_time.start();
    }
}
