package kmy.homework_1;

import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.TreeSet;

public class Activity_2 extends ListActivity {

    private NewAdapter new_list;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new_list = new NewAdapter();
        String[] units = {"", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"};
        String[] second_decade = {"десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать"};
        String[] decades = {"", "десять", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто"};
        String[] hundreds = {"сто", "двести", "триста", "четыреста", "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот", "тысяча"};
        String printed_number;
        for (int pos_num = 0; pos_num < 1000; pos_num++) {
            printed_number = "         ";
            if (pos_num < 9) {
                printed_number += units[pos_num + 1];
            }
            if (pos_num >= 9 && pos_num < 19) {
                printed_number += second_decade[(pos_num + 1) % 10];
            }
            if (pos_num >= 19 && pos_num < 99) {
                printed_number += decades[(pos_num + 1) / 10] + " " + units[(pos_num + 1) % 10];
            }
            if (pos_num >= 99 && pos_num < 1000) {
                if (((pos_num + 1) / 10) % 10 == 1)
                    printed_number += hundreds[(pos_num + 1) / 100 - 1] + " " + second_decade[(pos_num + 1) % 10];
                else {
                    if (((pos_num + 1) / 10) % 10 == 0)
                        printed_number += hundreds[(pos_num + 1) / 100 - 1] + " " + units[(pos_num + 1) % 10];
                    else
                        printed_number += hundreds[(pos_num + 1) / 100 - 1] + " " + decades[((pos_num + 1) / 10) % 10] + " " + units[(pos_num + 1) % 10];
                }
            }
            new_list.addItem(printed_number);
        }
        setListAdapter(new_list);
    }

    private class NewAdapter extends BaseAdapter {


        private ArrayList<String> mData = new ArrayList<String>();
        private LayoutInflater mInflater;

        public NewAdapter() {
            mInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public void addItem(final String item) {
            mData.add(item);
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return mData.size();
        }

        @Override
        public Object getItem(int position) {
            return mData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            System.out.println("getView " + position + " " + convertView);
            ViewHolder holder = null;
            convertView=null;
            switch(position%2) {

                case 0: {
                    convertView = mInflater.inflate(R.layout.activity_even, parent, false);
                    holder = new ViewHolder();
                    holder.textView = (TextView) convertView.findViewById(R.id.text1);
                    convertView.setTag(holder);
                    break;
                }

                case 1: {
                    convertView = mInflater.inflate(R.layout.activity_odd, parent, false);
                    holder = new ViewHolder();
                    holder.textView = (TextView) convertView.findViewById(R.id.text1);
                    convertView.setTag(holder);
                    break;
                }
            }
            holder = (ViewHolder)convertView.getTag();
            holder.textView.setText(mData.get(position));
            return convertView;
        }

    }
    public static class ViewHolder {
        public TextView textView;
    }

}
